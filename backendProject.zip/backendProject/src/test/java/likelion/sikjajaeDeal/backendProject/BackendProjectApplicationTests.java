package likelion.sikjajaeDeal.backendProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
